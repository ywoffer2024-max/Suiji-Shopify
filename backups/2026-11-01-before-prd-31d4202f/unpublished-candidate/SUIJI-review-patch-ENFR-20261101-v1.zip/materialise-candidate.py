#!/usr/bin/env python3
"""Materialise this review candidate into a NEW mutable checkout. No Store/API action."""
from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--target',type=Path,required=True);a=p.parse_args();r=Path(__file__).resolve().parent;t=a.target.expanduser().resolve()
if '/Volumes/T7/'in str(t)or str(t)=='/Volumes/T7':raise SystemExit('Choose a new local mutable checkout, not protected T7.')
if t.exists():raise SystemExit('Target must not exist; this tool never deletes or overwrites.')
d=json.loads((r/'candidate-file-index-final-v2.json').read_text());t.mkdir(parents=True)
for row in d['files']:
 rel=Path(row['path']);assert not rel.is_absolute()and'..'not in rel.parts
 src=Path(row['after_payload']);data=src.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'],rel
 out=t/rel;out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('xb')as f:f.write(data)
print(json.dumps({'target':str(t),'files':len(d['files']),'theme_files':d['theme_count'],'Store_writes':0}))
