#!/usr/bin/env python3
"""Sync confirmed ENFR guidance into Shopify locale namespaces in a mutable checkout."""
from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--theme',type=Path,required=True);p.add_argument('--source',type=Path,default=Path(__file__).resolve().parents[1]/'catalogue/storefront-guidance.json');p.add_argument('--check',action='store_true');a=p.parse_args()
s=json.loads(a.source.read_text());assert s['schema']=='suiji-guidance/1';assert set(s['en'])==set(s['fr']);assert all(isinstance(v,str)and'{{'not in v and'{%'not in v for lang in ('en','fr')for v in s[lang].values());changed=[]
for lang,name in [('en','en.default.json'),('fr','fr.json')]:
 f=a.theme/'locales'/name;raw=f.read_text();prefix=raw[:raw.index('{')];data=json.loads(raw[len(prefix):]);data['suiji_prd']=s[lang];want=prefix+json.dumps(data,ensure_ascii=False,indent=2)+'\n'
 if raw!=want:
  changed.append(name)
  if not a.check:
   if '/Volumes/T7/'in str(f.resolve()):raise RuntimeError('Use a fresh mutable checkout; protected T7 archives are immutable.')
   f.write_text(want)
print(json.dumps({'mode':'check'if a.check else'write','different_files':changed,'keys_per_locale':len(s['en'])}))
raise SystemExit(1 if a.check and changed else 0)
