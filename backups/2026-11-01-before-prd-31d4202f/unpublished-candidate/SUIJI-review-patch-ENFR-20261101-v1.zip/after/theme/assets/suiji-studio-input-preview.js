(() => {
  'use strict';
  const root = document.querySelector('[data-studio-preview]');
  if (!root) return;
  const labels = JSON.parse(root.querySelector('[data-studio-labels]').textContent);
  const text = root.querySelector('[data-studio-text]');
  const input = root.querySelector('[data-studio-image]');
  const source = root.querySelector('[data-studio-source]');
  const rights = root.querySelector('[data-studio-rights]');
  const status = root.querySelector('[data-studio-status]');
  const summary = root.querySelector('[data-studio-summary]');
  const figure = root.querySelector('[data-studio-image-preview]');
  const thumbnail = root.querySelector('[data-studio-thumbnail]');
  const remove = root.querySelector('[data-studio-remove]');
  let mode = 'text', file = null, imageURL = '';
  const say = message => { status.textContent = message; };
  const clearSummary = () => { summary.hidden = true; summary.replaceChildren(); say(''); };
  const clearImage = () => {
    if (imageURL) URL.revokeObjectURL(imageURL);
    imageURL = ''; file = null; input.value = ''; figure.hidden = true; remove.hidden = true; rights.checked = false;
    thumbnail.removeAttribute('src'); root.querySelector('[data-studio-filename]').textContent = ''; clearSummary();
  };
  root.querySelectorAll('[name="studio-input-mode"]').forEach(radio => radio.addEventListener('change', () => {
    mode = radio.value;
    rights.checked = false;
    root.querySelector('[data-studio-text-pane]').hidden = mode === 'image';
    root.querySelector('[data-studio-image-pane]').hidden = mode === 'text';
    clearSummary();
  }));
  input.addEventListener('change', () => {
    const selected = input.files[0];
    if (!selected) { clearImage(); return; }
    if (!/\.(jpe?g|png|webp|heic)$/i.test(selected.name) || selected.size > 10 * 1024 * 1024 || selected.size === 0) {
      clearImage(); say(labels.file_error); return;
    }
    if (imageURL) URL.revokeObjectURL(imageURL);
    file = selected; imageURL = ''; rights.checked = false; clearSummary();
    root.querySelector('[data-studio-filename]').textContent = selected.name;
    figure.hidden = false; remove.hidden = false;
    if (/\.heic$/i.test(selected.name)) {
      thumbnail.hidden = true; say(labels.preview_unavailable);
    } else {
      imageURL = URL.createObjectURL(selected); const currentURL = imageURL;
      thumbnail.hidden = false; thumbnail.alt = labels.file_selected;
      thumbnail.onerror = () => { if (imageURL === currentURL) { clearImage(); say(labels.file_error); } };
      thumbnail.src = imageURL;
    }
  });
  remove.addEventListener('click', clearImage);
  [text, source, root.querySelector('[data-studio-source-detail]')].forEach(el => el.addEventListener('input', () => { rights.checked = false; clearSummary(); }));
  rights.addEventListener('input', clearSummary);
  root.querySelector('[data-studio-preview-button]').addEventListener('click', () => {
    clearSummary();
    const description = mode === 'image' ? '' : text.value.trim();
    const reference = mode === 'text' ? null : file;
    if (!description && !reference) { say(labels.empty_error); return; }
    if (reference && (!source.value || source.value === '3')) { say(labels.rights_unknown); return; }
    if (!rights.checked) { say(labels.rights_error); return; }
    const heading = document.createElement('h3'); heading.textContent = labels.brief_title;
    const list = document.createElement('dl');
    const add = (label, value) => {
      if (!value) return;
      const dt = document.createElement('dt'), dd = document.createElement('dd');
      dt.textContent = label; dd.textContent = value; list.append(dt, dd);
    };
    add(labels.brief_text, description); add(labels.brief_image, reference?.name);
    summary.append(heading, list); summary.hidden = false; say(labels.preview_success);
  });
  window.addEventListener('pagehide', () => { if (imageURL) URL.revokeObjectURL(imageURL); });
})();
